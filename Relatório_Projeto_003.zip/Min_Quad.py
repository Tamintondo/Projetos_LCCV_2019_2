from Gauss_seidel import Gauss_seidel
import time
def Min_quad(x_coord,y_coord,grau):
        start = time.time()
        #A entrada consiste em duas listas e um numero. A primeira com as coordenadas X e outra
        #lista contendo os seus respectivos valores em y
        #E por fim um numero que indica o grau do polinomio
        tamanho = len(x_coord)
        Sum_x = []
        Sum_y = []
        #somatório de X^n que depende do grau do polinômio.
        for i in range (0,2**grau+1,1):
                valor=0
                for j in range (0,tamanho,1):
                        valor = valor + (x_coord[j])**i
                Sum_x.append(valor)
        #Em seguida o somatório para Y*X^n que também depende do grau do polinômio.
        for i in range (0,grau+1,1):
                valor = 0
                for j in range (0,tamanho,1):
                        valor  = valor + y_coord[j]*(x_coord[j]**i)
                Sum_y.append(valor)
        #   A partir daqui temos os vetores que irao compor a matriz 
        #que determina os coeficientes do polinomio
        matriz = []
        n = 0
        for i in range (0,grau+1,1):
                vetor = []
                for j in range (0,grau+1,1):
                        vetor.append(Sum_x[j+n])
                n =n + 1
                matriz.append(vetor)
                
        ans  = Gauss_seidel(matriz,Sum_y,(grau+1))
        end = time.time()
        tempo = (end - start)
        return tempo , ans
      
        
        
