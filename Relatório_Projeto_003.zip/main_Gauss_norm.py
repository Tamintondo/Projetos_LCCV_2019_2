import numpy as np
import time
import random
from Matriz_aleatoria_nxn import Matriz_aleatoria_nxn
from Gauss_seidel import Gauss_seidel

def main(n):
    start = time.time()
    matriz, vetor,n = Matriz_aleatoria_nxn(n)
    ans = Gauss_seidel(matriz,vetor,n)
    end = time.time()
    tempo = (end - start)
    return ans, tempo
    
