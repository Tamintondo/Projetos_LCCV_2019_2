import numpy as np
import matplotlib.pyplot as plt
from scipy import integrate
import polinomio
import time
start = time.time()
def func_pol(x):
    return (6*(x**6)+5*(x**5)+4*(x**4)+3*(x**3)+2*(x**2)+(x))

int,err = integrate.quad(func_pol,0,3)
print(f'Integral: {int} e Erro: {err}')
end = time.time()
tempo = (end - start)
print (tempo)

