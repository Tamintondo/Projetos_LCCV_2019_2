def func_pol(x):
    return 6*(x**6)+5*(x**5)+4*(x**4)+3*(x**3)+2*(x**2)+x
