def Gauss_seidel(matriz,vetor,n):
        solucao_ant = [0 for _ in range(n)]
        solucao_pos = [0 for _ in range(n)]
        erro = [10 for _ in range(n)]
        tolerancia = 0.1
        flag = 0
        while flag != n:
                flag = 0
                for i in range (0,n,1):
                        for j in range (0,n,1):
                                if i != j:
                                        solucao_pos[i] += matriz[i][j]*solucao_ant[j]
                                elif matriz[i][i]  == 0:
                                         print('Erro encontrado! A diagonal principal contém zeros')
                                         break
                        solucao_pos[i] = (1/matriz[i][i])*(vetor[i] - solucao_pos[i])
                        erro[i] = abs(solucao_pos[i] - solucao_ant[i])
                        solucao_ant[i] = solucao_pos[i]
                        solucao_pos = [0 for _ in range(n)]
                        if erro[i] < tolerancia:
                                flag= flag + 1
        return solucao_ant



        
        
        
    
