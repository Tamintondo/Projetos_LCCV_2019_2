#!/usr/bin/env python
# coding: utf-8
# ## Importando Módulo ## #
#C:\Users\User\Documents\UFAL\LCCV\Projeto 003\Atividade 1\Solução com pacotes
import numpy as np
def Gauss_seidel_num (matriz,vetor):
	ans = np.linalg.solve(matriz,vetor)
	return ans


