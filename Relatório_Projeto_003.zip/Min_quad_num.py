#!/usr/bin/env python
# coding: utf-8

# In[1]:
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from scipy.stats import linregress
# In[2]:
def func_pri(x,a,b):
    return a*x+b
def func_sec(x,a,b,c):
    return a*x**2 + b*x + c
def func_ter(x,a,b,c,d):
    return a*(x**3) + b*(x**2) +c*(x) +d
def func_qua(x,a,b,c,d,e):
    return a*(x**4) + b*(x**3) + c*(x**2) +d*(x) +e

def Min_quad_num(grau,x_coord,y_coord):
	if grau == 1:
		popt,pcov = curve_fit(func_pri,x_coord,y_coord)
		return popt
	elif grau == 2:
		popt,pcov = curve_fit(func_sec,x_coord,y_coord)
		return popt
	elif grau == 3:
		popt,pcov = curve_fit(func_ter,x_coord,y_coord)
		return popt
	elif grau == 4:
		 popt,pcov = curve_fit(func_qua,x_coord,y_coord)
		return popt
'''
x_data= np.linspace(0,1,20)
y_ans = func_quad(x_data,2.5,4.3,9)
y_noise = 1*np.random.normal(size=x_data.size)
y_data = y_ans+y_noise
plt.plot(x_data,y_ans,'ro')
plt.plot(x_data,y_data,'g-')


# In[4]:


popt,pcov = curve_fit(func_quad,x_data,y_data)
print(f'Opt. Values:{popt}')
print(f'Std. Covariance:{np.sqrt(np.diag(pcov))} ')


# In[ ]:





# In[5]:


y_fit = popt[0]*x_data**2+popt[1]*x_data+popt[2]
plt.plot(x_data,y_data,'ro')
plt.plot(x_data,y_fit,'g-')


# In[6]:


popt2,pcov2 = curve_fit(func_quad,x_data,y_data,bounds=([2,4,8.5],[3,5,9.5]))
print(f'Opt. Values:{popt2}')
print(f'Std. Covariance:{np.sqrt(np.diag(pcov2))}')


# In[7]:


y_fit = popt2[0]*x_data**2+popt2[1]*x_data+popt2[2]
plt.plot(x_data,y_data,'ro')
plt.plot(x_data,y_fit,'g-')


# In[8]:


a,b,rValue,pValue, stderr=linregress(x_data,y_data)
print(f'A:{a}, B:{b}, R:{rValue}, Erro:{stderr},')


# In[9]:


plt.plot(x_data,y_data,'ro')
plt.plot(x_data,a*x_data+b,'g-')


# In[ ]:

'''


