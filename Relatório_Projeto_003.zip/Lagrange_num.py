#!/usr/bin/env python
# coding: utf-8
get_ipython().run_line_magic('matplotlib', 'inline')
import numpy as np
from scipy.interpolate import lagrange
import matplotlib.pyplot as plt
from polinomio import polinomio 

def Lagrange_num(x_data):
	x_coord = np.array(x_data)
	y_coord = polinomio(x_data)
	poly_lag = lagrange(x_pt,y_pt)
	ans = (np.polynomial.polynomial.Polynomial(poly_lag).coef)
	return ans


	
print(x_pt)
plt.plot(x_pt,y_pt,'o', color = 'red')
print(poly_lag)
print(np.polynomial.polynomial.Polynomial(poly_lag).coef)
x_tst = np.linspace(0,8,20)
y_tst = poly_lag(x_tst)
plt.plot(x_tst,y_tst,'b-')
plt.plot(x_pt,y_pt,'ro')
plt.title('Grafico')