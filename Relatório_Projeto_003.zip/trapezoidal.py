def trapezoidal(funcao, a, b, n):
    h = float(b-a)/n
    result = 0.5*funcao(a) + 0.5*funcao(b)
    for i in range(1, n):
        result += funcao(a + i*h)
    result *= h
    return result

		

