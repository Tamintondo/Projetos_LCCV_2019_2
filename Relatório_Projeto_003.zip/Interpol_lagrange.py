from Gauss_seidel import Gauss_seidel
def Interpol_lagrange (x_data,y_data,grau):
        matriz  = []
        for i in range (0,grau+1,1):
                vetor = []
                for j in range (0,grau+1,1):
                        vetor.append(x_data[i]**j)
                matriz.append(vetor)
        print(matriz)
        print(y_data)
        solucao = Gauss_seidel(matriz,y_data,(grau+1))
        return solucao


        

