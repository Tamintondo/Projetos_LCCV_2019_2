
def MDC(a,b):
    
    anterior = a
    atual    = b
    resto    = anterior % atual

    while resto != 0:
        anterior = atual
        atual    = resto
        resto    = anterior % atual
