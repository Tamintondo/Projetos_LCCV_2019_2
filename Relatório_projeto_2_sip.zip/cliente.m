import Gerador_de_chave
import MDC
import encrypt
import decrypt

class Cliente (flag, chavepub,chavepriv):
	 dados = []
	 contador = 0
	def __init__ (self):
	while True:
		user = input('')
		if user == flag:
			break
		else:
			password = input('')
			dados.append(user)
		except:
			print('Sinto muito, não foi dessa vez, amigo, tenta de novo amanha!')
	
	def procurar(nome):
		posicao = filter(nome)
		
	def apagar(procurar,ordem)
		if ordem == 1:
			posicao.remove(nome)
		else:
           ordem  = 0
    if chavepriv == 0 or chavepub == 0
    Gerador_de_chave_pub()
    Gerador_de_chave_priv()
    encrypt()
    decrypt()