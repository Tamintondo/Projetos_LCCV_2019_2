def Encrypt (totiente, expoente, mensagem):

'''
############## função deve receber dois numeros chave  = [totiente, i]  e também uma entrada com uma string em seguida
'''
	mensagem = mensagem.split('')
	tamanho = len(mensagem)
	for i in range (0, tamanho, 1):
		'''
		####### neste caso o comprimento vai variar de acordo com cada palavra adicionada
		'''
		comprimento = len(mensagem[i])
		for  j range (0, comprimento, 1):
			valor = ord(mensagem[i][j])
			mensagem[i][j] = chr((valor**expoente)%totiente)
